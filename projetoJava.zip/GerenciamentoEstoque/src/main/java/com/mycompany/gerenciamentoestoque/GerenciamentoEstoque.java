/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.gerenciamentoestoque;
import View.*;
/**
 *
 * @author aluno.den
 */
public class GerenciamentoEstoque {

    public static void main(String[] args) {
        TelaLogin lg = new TelaLogin();
        lg.setVisible(true);
        
    }
}
