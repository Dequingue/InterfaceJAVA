/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DTO;

/**
 *
 * @author LUIZ
 */
public class ProdutosDTO {
    private String nome_produto, descricao_produto;
    private int quantidade_produto,usuario_id;
    private Double preco_produto;

    /**
     * @return the nome_produto
     */
    public String getNome_produto() {
        return nome_produto;
    }

    /**
     * @param nome_produto the nome_produto to set
     */
    public void setNome_produto(String nome_produto) {
        this.nome_produto = nome_produto;
    }

    /**
     * @return the descricao_produto
     */
    public String getDescricao_produto() {
        return descricao_produto;
    }

    /**
     * @param descricao_produto the descricao_produto to set
     */
    public void setDescricao_produto(String descricao_produto) {
        this.descricao_produto = descricao_produto;
    }

    /**
     * @return the quantidade_produto
     */
    public int getQuantidade_produto() {
        return quantidade_produto;
    }

    /**
     * @param quantidade_produto the quantidade_produto to set
     */
    public void setQuantidade_produto(int quantidade_produto) {
        this.quantidade_produto = quantidade_produto;
    }

    /**
     * @return the usuario_id
     */
    public int getUsuario_id() {
        return usuario_id;
    }

    /**
     * @param usuario_id the usuario_id to set
     */
    public void setUsuario_id(int usuario_id) {
        this.usuario_id = usuario_id;
    }

    /**
     * @return the preco_produto
     */
    public Double getPreco_produto() {
        return preco_produto;
    }

    /**
     * @param preco_produto the preco_produto to set
     */
    public void setPreco_produto(Double preco_produto) {
        this.preco_produto = preco_produto;
    }

    /**
     * @return the nome_produto
     */
   
    
}
