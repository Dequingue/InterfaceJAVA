/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DTO;

/**
 *
 * @author LUIZ
 */
public class CadastroDTO {
    private String nome_cadastrar, senha_cadastrar;
    public String getNome_cadastrar() {
        return nome_cadastrar;
    }

    public void setNome_cadastrar(String nome_cadastrar) {
        this.nome_cadastrar = nome_cadastrar;
    }

    public String getSenha_cadastrar() {
        return senha_cadastrar;
    }

    public void setSenha_cadastrar(String senha_cadastrar) {
        this.senha_cadastrar = senha_cadastrar;
    }
    
    
}
